class Char {
    constructor(name, walk, run, idle  ) {
      this.name = name;
      this.walk = walk; 
      this.run = run;
      this.idle = idle; 
      this.char; 
    }
  
    loadChar()
    {
      char = loadeImage(this.name)
    }

    drawChar()
    {

    }
    
  
  
  
  
  

  
  }